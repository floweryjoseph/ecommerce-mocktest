
const CartDetailsPage = () => {
  return (
    <div className="w-full">

    </div>
  )
}

export default CartDetailsPage