import { useState } from 'react';
import Navbar from './components/Navbar';
import ProductsPage from './pages/ProductsPage';


const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [cartItems, setCartItems] = useState([]); 

  return (
    <div>
      <Navbar searchTerm={searchTerm} setSearchTerm={setSearchTerm} cartItems={cartItems} />
      <ProductsPage searchTerm={searchTerm} cartItems={cartItems} setCartItems={setCartItems} />
    </div>
  );
};

export default App;
